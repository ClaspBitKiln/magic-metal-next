﻿# Requires PowerShell 5.1 or later. No API keys, tunnels, services or administrator rights.
[CmdletBinding()]
param(
    [string]$VaultPath,
    [string]$SourcePath,
    [string]$StateRoot,
    [string]$RegistryPath,
    [switch]$SkipInstall,
    [switch]$Scheduled
)
$ErrorActionPreference = 'Stop'
$sourceUrl = 'https://raw.githubusercontent.com/ClaspBitKiln/magic-metal-next/main/docs/ai/OBSIDIAN_PENDING_RF_CATALOG_AND_CONNECTIONS_2026-10-14.md'
$noteRelative = 'Мэджик Металл/Синхронизация из GitHub/Каталог и подключения — 2026-10-14.md'
$utf8 = New-Object System.Text.UTF8Encoding($false)
if (-not $StateRoot) {
    if (-not $env:LOCALAPPDATA) { throw 'Не найдена папка LOCALAPPDATA.' }
    $StateRoot = Join-Path $env:LOCALAPPDATA 'MagicMetalObsidianSync'
}
[System.IO.Directory]::CreateDirectory($StateRoot) | Out-Null
$stateFile = Join-Path $StateRoot 'state.json'
$logFile = Join-Path $StateRoot 'sync.log'
function Write-SyncLog([string]$Message) {
    $line = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $Message + [Environment]::NewLine
    if ((Test-Path -LiteralPath $logFile) -and (Get-Item -LiteralPath $logFile).Length -gt 65536) {
        [System.IO.File]::WriteAllText($logFile, '', $utf8)
    }
    [System.IO.File]::AppendAllText($logFile, $line, $utf8)
}
function Get-TextHash([string]$Text) {
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash($utf8.GetBytes($Text)))).Replace('-', '').ToLowerInvariant() }
    finally { $sha.Dispose() }
}
function Test-Vault([string]$Path) {
    return $Path -and (Test-Path -LiteralPath (Join-Path $Path '.obsidian') -PathType Container)
}
function Select-Vault {
    if ($VaultPath) {
        if (-not (Test-Vault $VaultPath)) { throw 'Выбранная папка не является хранилищем Obsidian (.obsidian не найден).' }
        return [System.IO.Path]::GetFullPath($VaultPath)
    }
    if (-not $RegistryPath) {
        if (-not $env:APPDATA) { throw 'Не найдена папка APPDATA.' }
        $script:RegistryPath = Join-Path $env:APPDATA 'obsidian/obsidian.json'
    }
    $candidates = @()
    if (Test-Path -LiteralPath $RegistryPath -PathType Leaf) {
        $registry = [System.IO.File]::ReadAllText($RegistryPath) | ConvertFrom-Json
        if ($registry.vaults) {
            foreach ($entry in $registry.vaults.PSObject.Properties) {
                if (Test-Vault $entry.Value.path) {
                    $candidates += [PSCustomObject]@{ path = [System.IO.Path]::GetFullPath($entry.Value.path); open = [bool]$entry.Value.open }
                }
            }
        }
    }
    $named = @($candidates | Where-Object { [System.IO.Path]::GetFileName($_.path.TrimEnd([char[]]@('/', '\'))) -eq 'inn-bot' })
    if ($named.Count -eq 1) { return $named[0].path }
    if ($candidates.Count -eq 1) { return $candidates[0].path }
    $opened = @($candidates | Where-Object { $_.open })
    if ($opened.Count -eq 1) { return $opened[0].path }
    if ($Scheduled) { throw 'Не удалось однозначно выбрать хранилище. Запустите программу вручную.' }
    if ($env:OS -ne 'Windows_NT') { throw 'Не удалось однозначно выбрать хранилище.' }
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = 'Выберите папку хранилища Obsidian (inn-bot).'
    $dialog.ShowNewFolderButton = $false
    try {
        if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { throw 'Выбор хранилища отменён.' }
        if (-not (Test-Vault $dialog.SelectedPath)) { throw 'В выбранной папке отсутствует .obsidian.' }
        return $dialog.SelectedPath
    } finally { $dialog.Dispose() }
}
$lock = $null
$temp = $null
try {
    $lock = [System.IO.File]::Open((Join-Path $StateRoot 'sync.lock'), [System.IO.FileMode]::OpenOrCreate, [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::None)
    $state = $null
    if (Test-Path -LiteralPath $stateFile) { $state = [System.IO.File]::ReadAllText($stateFile) | ConvertFrom-Json }
    if (-not $VaultPath -and $state -and $state.vaultPath -and (Test-Vault $state.vaultPath)) { $VaultPath = $state.vaultPath }
    $selectedVault = Select-Vault
    if ($SourcePath) {
        $download = [System.IO.File]::ReadAllText([System.IO.Path]::GetFullPath($SourcePath), $utf8)
    } else {
        [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
        $temp = Join-Path $StateRoot ('download-' + [Guid]::NewGuid().ToString('N') + '.tmp')
        Invoke-WebRequest -Uri $sourceUrl -UseBasicParsing -TimeoutSec 25 -MaximumRedirection 3 -OutFile $temp
        $download = [System.IO.File]::ReadAllText($temp, $utf8)
        Remove-Item -LiteralPath $temp -Force
        $temp = $null
    }
    if ($utf8.GetByteCount($download) -gt 1048576 -or $download.Length -lt 100 -or -not $download.StartsWith('---') -or $download.IndexOf([char]0) -ge 0 -or $download -notmatch 'project:\s*Сайт — Мэджик Металл') {
        throw 'Источник не похож на ожидаемую заметку проекта. Запись отменена.'
    }
    $destination = Join-Path $selectedVault $noteRelative
    $sourceHash = Get-TextHash $download
    $outcome = 'created'
    if (Test-Path -LiteralPath $destination) {
        $currentHash = Get-TextHash ([System.IO.File]::ReadAllText($destination, $utf8))
        if ($currentHash -eq $sourceHash) { $outcome = 'unchanged' }
        elseif (-not $state -or $state.noteHash -ne $currentHash -or $state.vaultPath -ne $selectedVault) {
            throw 'Заметка изменена пользователем. Она сохранена; автоматическая перезапись отменена.'
        } else { $outcome = 'updated' }
    }
    if ($outcome -ne 'unchanged') {
        [System.IO.Directory]::CreateDirectory([System.IO.Path]::GetDirectoryName($destination)) | Out-Null
        $temp = Join-Path ([System.IO.Path]::GetDirectoryName($destination)) ('.magic-metal-' + [Guid]::NewGuid().ToString('N') + '.tmp')
        [System.IO.File]::WriteAllText($temp, $download, $utf8)
        if ($outcome -eq 'created') { [System.IO.File]::Move($temp, $destination) }
        else {
            # Check again immediately before atomic replacement, preserving user changes.
            if ((Get-TextHash ([System.IO.File]::ReadAllText($destination, $utf8))) -ne $currentHash) { throw 'Заметка изменена во время синхронизации. Запись отменена.' }
            [System.IO.File]::Replace($temp, $destination, [NullString]::Value)
        }
        $temp = $null
    }
    if ((Get-TextHash ([System.IO.File]::ReadAllText($destination, $utf8))) -ne $sourceHash) { throw 'Проверка сохранённой заметки не прошла.' }
    $newState = [ordered]@{ vaultPath = $selectedVault; noteHash = $sourceHash; lastSync = (Get-Date).ToUniversalTime().ToString('o'); sourceUrl = $sourceUrl }
    $temp = Join-Path $StateRoot ('state-' + [Guid]::NewGuid().ToString('N') + '.tmp')
    [System.IO.File]::WriteAllText($temp, ($newState | ConvertTo-Json), $utf8)
    if (Test-Path -LiteralPath $stateFile) { [System.IO.File]::Replace($temp, $stateFile, [NullString]::Value) }
    else { [System.IO.File]::Move($temp, $stateFile) }
    $temp = $null
    if (-not $SkipInstall -and -not $Scheduled) {
        if ($env:OS -ne 'Windows_NT') { throw 'Автозапуск устанавливается только в Windows.' }
        $installedScript = Join-Path $StateRoot 'Sync-Obsidian.ps1'
        if ([System.IO.Path]::GetFullPath($PSCommandPath) -ne [System.IO.Path]::GetFullPath($installedScript)) {
            Copy-Item -LiteralPath $PSCommandPath -Destination $installedScript -Force
        }
        $startup = [Environment]::GetFolderPath([Environment+SpecialFolder]::Startup)
        if (-not $startup) { throw 'Не найдена папка автозагрузки текущего пользователя.' }
        $shell = New-Object -ComObject WScript.Shell
        $shortcut = $shell.CreateShortcut((Join-Path $startup 'MagicMetal Obsidian Sync.lnk'))
        $shortcut.TargetPath = Join-Path $env:SystemRoot 'System32/WindowsPowerShell/v1.0/powershell.exe'
        $shortcut.Arguments = '-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "' + $installedScript + '" -Scheduled'
        $shortcut.WorkingDirectory = $StateRoot
        $shortcut.WindowStyle = 7
        $shortcut.Description = 'Обновление заметки Мэджик Металл в Obsidian при входе в Windows'
        $shortcut.Save()
    }
    Write-SyncLog ('OK ' + $outcome)
    if (-not $Scheduled) {
        Write-Host 'Готово. Заметка сохранена и проверена в Obsidian:' -ForegroundColor Green
        Write-Host $destination
        if (-not $SkipInstall) { Write-Host 'Автоматическое обновление включено при входе в Windows.' }
    }
    exit 0
} catch {
    Write-SyncLog ('ERROR ' + $_.Exception.Message)
    if (-not $Scheduled) { Write-Host ('Ошибка: ' + $_.Exception.Message) -ForegroundColor Red }
    exit 1
} finally {
    if ($temp -and (Test-Path -LiteralPath $temp)) { Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue }
    if ($lock) { $lock.Dispose() }
}
