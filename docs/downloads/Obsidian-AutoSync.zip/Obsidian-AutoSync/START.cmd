@echo off
setlocal
cd /d "%~dp0"
echo Obsidian: copying the Magic Metal note and setting up login sync...
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Sync-Obsidian.ps1"
set "sync_result=%errorlevel%"
echo.
pause
exit /b %sync_result%
