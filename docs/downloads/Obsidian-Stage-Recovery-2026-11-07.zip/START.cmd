@echo off
setlocal
cd /d "%~dp0"
if /I not "%COMPUTERNAME%"=="DESKTOP-BNPIVK2" goto wronghost
if not "%OS%"=="Windows_NT" goto wronghost
for %%F in (disable_obsidian_autosync.ps1 diagnose_remote_desktop_commander.ps1 obsidian-recovery.mjs) do (
  if not exist "%~dp0scripts\%%F" goto incomplete
)
if not defined LOCALAPPDATA goto incomplete
if not exist "%LOCALAPPDATA%\MagicMetalObsidianSync" mkdir "%LOCALAPPDATA%\MagicMetalObsidianSync"
echo Disabling note-sync timers and login shortcuts. Keeping Remote access.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\disable_obsidian_autosync.ps1" -Apply > "%LOCALAPPDATA%\MagicMetalObsidianSync\manual-sync-disable.log" 2>&1
set "SYNC_EXIT=%ERRORLEVEL%"
type "%LOCALAPPDATA%\MagicMetalObsidianSync\manual-sync-disable.log"
echo.
echo Checking existing Obsidian and Remote. An existing Remote will not restart.
echo If a new Remote window needs authorization, use its NEW link only.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\diagnose_remote_desktop_commander.ps1" -Action Recover
set "RECOVERY_EXIT=%ERRORLEVEL%"
echo.
echo Disable-sync result: %SYNC_EXIT% ; Local diagnosis result: %RECOVERY_EXIT%
echo A nonzero result needs review. No ChatGPT connection is claimed by this program.
echo Logs: %LOCALAPPDATA%\MagicMetalObsidianSync
echo Remote process and local API do not prove ChatGPT tool availability.
echo Work-stage notes must be saved by the working AI chat, then read back.
pause
if not "%SYNC_EXIT%"=="0" exit /b %SYNC_EXIT%
exit /b %RECOVERY_EXIT%
:wronghost
echo This package is for Windows DESKTOP-BNPIVK2 only. Nothing changed.
pause
exit /b 5
:incomplete
echo Extract the entire ZIP first. Required files or LOCALAPPDATA are missing.
pause
exit /b 4
