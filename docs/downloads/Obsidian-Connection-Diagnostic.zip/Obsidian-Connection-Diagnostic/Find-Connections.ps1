param(
    [string]$AppDataPath = $env:APPDATA,
    [string]$UserProfilePath = $env:USERPROFILE,
    [string]$ReportPath = (Join-Path $PSScriptRoot 'CONNECTION-REPORT.txt')
)
$ErrorActionPreference = 'Stop'
$report = New-Object 'System.Collections.Generic.List[string]'
function Add-Line([string]$Text) { $report.Add($Text) }
function Safe-Name([string]$Text) {
    if ($Text -match '(?i)(bearer\s|(?:sk-|fc-|ghp_|github_pat_)[a-z0-9_-]+|[a-f0-9]{40,})') { return '[redacted]' }
    return (($Text -replace '[\r\n\t]', ' ') | Select-Object -First 1)
}
function Read-Json([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { Add-Line ('Not found: ' + $Path); return $null }
    try { return (Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json) }
    catch { Add-Line ('Cannot read valid JSON: ' + $Path); return $null }
}
function Safe-Url([object]$Value) {
    if ($Value -isnot [string]) { return '[non-string URL omitted]' }
    try {
        $url = New-Object System.Uri($Value)
        if (-not $url.IsAbsoluteUri -or $url.Scheme -notin @('http','https')) { return '[non-HTTP URL omitted]' }
        $authority = $url.Host
        if ($authority.Contains(':')) { $authority = '[' + $authority + ']' }
        if (-not $url.IsDefaultPort) { $authority += ':' + $url.Port }
        $path = $url.AbsolutePath
        foreach ($segment in ($path -split '/')) {
            $decoded = [System.Uri]::UnescapeDataString($segment)
            if ($decoded.Length -ge 20 -or $decoded -match '(?i)(token|secret|password|api.?key|bearer|^(sk-|fc-|ghp_|github_pat_))') { $path = '/[path omitted]'; break }
        }
        return ($url.Scheme + '://' + $authority + $path)
    } catch { return '[invalid URL omitted]' }
}
function Inspect-Mcp([string]$Path) {
    Add-Line ''; Add-Line ('Configuration: ' + $Path)
    $json = Read-Json $Path
    if ($null -eq $json) { return }
    if ($null -eq $json.mcpServers) { Add-Line 'No mcpServers section.'; return }
    foreach ($entry in $json.mcpServers.PSObject.Properties) {
        $server = $entry.Value
        $transport = 'unspecified'
        if ($null -ne $server.command) { $transport = 'stdio (command and arguments omitted)' }
        if ($null -ne $server.url) { $transport = 'HTTP'; Add-Line ('URL: ' + (Safe-Url $server.url)) }
        if ($server.type -is [string] -and $server.type -in @('http','sse','stdio')) { $transport = $server.type }
        Add-Line ('Server: ' + (Safe-Name $entry.Name) + '; transport: ' + $transport)
        foreach ($field in @('headers','env')) {
            if ($null -ne $server.$field) {
                $names = @($server.$field.PSObject.Properties | ForEach-Object { Safe-Name $_.Name })
                Add-Line ($field + ' names only: ' + ($names -join ', '))
            }
        }
    }
}
Add-Line 'Obsidian / MCP connection diagnostic'
Add-Line 'Read-only inspection. Secret values, commands, arguments and certificates are omitted.'
Add-Line ('UTC: ' + [DateTime]::UtcNow.ToString('yyyy-MM-dd HH:mm:ss'))
if ([string]::IsNullOrWhiteSpace($AppDataPath) -or [string]::IsNullOrWhiteSpace($UserProfilePath)) {
    throw 'APPDATA and USERPROFILE paths are required.'
}
$configs = @(
    (Join-Path $AppDataPath 'Claude/claude_desktop_config.json'),
    (Join-Path $UserProfilePath '.cursor/mcp.json'),
    (Join-Path $UserProfilePath 'Documents/inn-bot/.cursor/mcp.json'),
    (Join-Path $UserProfilePath '.claude/settings.json')
)
foreach ($path in $configs) { Inspect-Mcp $path }
Add-Line ''; Add-Line 'Obsidian vault registry:'
$registry = Read-Json (Join-Path $AppDataPath 'obsidian/obsidian.json')
if ($null -ne $registry -and $null -ne $registry.vaults) {
    foreach ($entry in $registry.vaults.PSObject.Properties) {
        $vault = $entry.Value.path
        if ($vault -isnot [string] -or [string]::IsNullOrWhiteSpace($vault)) { continue }
        Add-Line ('Vault path: ' + $vault)
        $gitConfigPath = Join-Path $vault '.git/config'
        if (Test-Path -LiteralPath $gitConfigPath -PathType Leaf) {
            Add-Line 'Vault Git configuration exists.'
            try {
                foreach ($line in (Get-Content -LiteralPath $gitConfigPath -Encoding UTF8)) {
                    if ($line -match '^\s*url\s*=\s*(.+)\s*$') {
                        $remote = $Matches[1].Trim()
                        if ($remote -match '^https?://') { Add-Line ('Git remote: ' + (Safe-Url $remote)) }
                        elseif ($remote -match '^(?:[^@\s]+@)?([a-zA-Z0-9.-]+):[^\s]+$') { Add-Line ('Git SSH remote host: ' + $Matches[1]) }
                        elseif ($remote -match '^ssh://(?:[^@/\s]+@)?([a-zA-Z0-9.-]+)') { Add-Line ('Git SSH remote host: ' + $Matches[1]) }
                        else { Add-Line 'Git remote present (address omitted).' }
                    }
                }
            } catch { Add-Line 'Cannot read vault Git metadata.' }
        }
        $enabled = @()
        $communityPath = Join-Path $vault '.obsidian/community-plugins.json'
        if (Test-Path -LiteralPath $communityPath -PathType Leaf) {
            $community = Read-Json $communityPath
            if ($null -ne $community) { $enabled = @($community) }
        }
        $pluginsPath = Join-Path $vault '.obsidian/plugins'
        if (-not (Test-Path -LiteralPath $pluginsPath -PathType Container)) { Add-Line 'Plugin directory not found.'; continue }
        foreach ($dir in (Get-ChildItem -LiteralPath $pluginsPath -Directory | Select-Object -First 100)) {
            $manifestPath = Join-Path $dir.FullName 'manifest.json'
            if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) { continue }
            $manifest = Read-Json $manifestPath
            if ($null -eq $manifest -or $manifest.id -isnot [string]) { continue }
            $id = $manifest.id
            Add-Line ('Installed plugin: ' + (Safe-Name $id))
            if ($id -eq 'obsidian-git') {
                Add-Line ('Obsidian Git enabled: ' + ($enabled -contains $id))
                Add-Line ('Obsidian Git settings present: ' + (Test-Path -LiteralPath (Join-Path $dir.FullName 'data.json') -PathType Leaf))
            }
            if ($id -notmatch '(?i)(rest.?api|obsidian.*mcp|mcp.*obsidian)') { continue }
            Add-Line ('REST/MCP plugin: ' + (Safe-Name $id) + '; enabled: ' + ($enabled -contains $id))
            $data = Read-Json (Join-Path $dir.FullName 'data.json')
            if ($null -eq $data) { continue }
            $hasKey = $false
            foreach ($property in $data.PSObject.Properties) {
                if ($property.Name -match '^(apiKey|api_key|token|authToken)$' -and -not [string]::IsNullOrEmpty([string]$property.Value)) { $hasKey = $true }
                if ($property.Name -in @('port','httpPort','httpsPort','securePort','insecurePort','enableInsecureServer','enableSecureServer','enableMcp','enabled','enableHttp','enableHttps')) {
                    if ($property.Value -is [bool] -or $property.Value -is [int] -or $property.Value -is [long]) {
                        Add-Line ((Safe-Name $property.Name) + ': ' + $property.Value)
                    }
                }
            }
            Add-Line ('API key present: ' + $hasKey + ' (value omitted)')
        }
    }
}
Add-Line ''; Add-Line 'No connections were started and no settings were changed.'
$reportFullPath = [System.IO.Path]::GetFullPath($ReportPath)
# Never allow a diagnostic report to overwrite an inspected JSON configuration.
if ([System.IO.Path]::GetExtension($reportFullPath) -ne '.txt' -or (Test-Path -LiteralPath $reportFullPath -PathType Container)) { throw 'ReportPath must be a .txt file.' }
$utf8 = New-Object System.Text.UTF8Encoding($true)
[System.IO.File]::WriteAllLines($reportFullPath, $report, $utf8)
Write-Host ('Report saved: ' + $reportFullPath)
