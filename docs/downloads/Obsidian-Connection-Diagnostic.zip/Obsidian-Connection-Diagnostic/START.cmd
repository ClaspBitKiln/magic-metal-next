@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Find-Connections.ps1"
if errorlevel 1 (
  echo Diagnostic failed. Settings have not been changed.
) else (
  start "" notepad.exe "%~dp0CONNECTION-REPORT.txt"
)
pause
