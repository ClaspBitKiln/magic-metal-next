@echo off
setlocal
cd /d "%~dp0"
where node.exe >nul 2>&1
if errorlevel 1 (
  echo Node.js is missing. No changes were made.
  pause
  exit /b 2
)
node.exe --check "%~dp0scripts\obsidian-recovery.mjs"
if errorlevel 1 (
  echo Recovery program check failed. No changes were made.
  pause
  exit /b 3
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\diagnose_remote_desktop_commander.ps1" -Action Recover
set "RECOVERY_EXIT=%ERRORLEVEL%"
echo.
echo Recovery finished with code %RECOVERY_EXIT%.
echo Report: %LOCALAPPDATA%\MagicMetalObsidianSync\recovery-report.json
echo Local API is optional for direct Remote file access.
echo Local API readiness does not prove ChatGPT connector availability.
pause
exit /b %RECOVERY_EXIT%
