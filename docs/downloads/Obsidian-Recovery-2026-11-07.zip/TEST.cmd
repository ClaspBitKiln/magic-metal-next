@echo off
cd /d "%~dp0"
node.exe tests/obsidian-recovery.test.mjs
set "TEST_EXIT=%ERRORLEVEL%"
pause
exit /b %TEST_EXIT%
